﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_La_Magnifica
{
    public partial class MenuPrincipal : Form
    {
        public MenuPrincipal()
        {
            InitializeComponent();
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {

        }

        private void cadastroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CadastraLogin tela = new CadastraLogin();
            tela.Show();
        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MenuPrincipal tela = new MenuPrincipal();
            tela.Show();
        }

        private void menuPrincipalToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void agendamentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Agendamento tela = new Agendamento();
            tela.Show();
        }

        private void produtosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CadastraProduto tela = new
            CadastraProduto();
            tela.Show();
        }

        private void deliveryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ItensdosPedidos tela = new 
            ItensdosPedidos();
            tela.Show();
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clientes tela = new Clientes(); 
            tela.Show();
        }
    }
}
