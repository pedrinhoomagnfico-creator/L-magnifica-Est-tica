﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.CodeDom;

namespace Projeto_La_Magnifica
{
    public partial class CadastraLogin : Form
    {
        public CadastraLogin()
        {
            InitializeComponent();
        }

        private void btnCadastraLogin_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(
                    @"Data Source=.\SQLEXPRESS;InitialCatalog=ClinicaEstetica;Integrated Security=True");

                conn.Open();

                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO Cliente (nomeCliente, email, endereco, senha, dataNascimento) VALUES (@nome,@email,@endereco,@senha,@data)", conn);


                cmd.Parameters.AddWithValue("@nome", txtNomeCompleto.Text);
                cmd.Parameters.AddWithValue("@email", txtCelularEmail.Text);
                cmd.Parameters.AddWithValue("@endereço", txtEndereçoCompleto.Text);
                cmd.Parameters.AddWithValue("@senha", txtSenha.Text);
                cmd.Parameters.AddWithValue("@DataNascimento", txtDataNascimento.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Cadastro realizado com sucesso!");

                conn.Close();
            }
            catch (Exception erro)
            {
                MessageBox.Show("Erro ao cadastrar:" + erro.Message);
            }
        }

        private void btnLoginTela_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection("Sua_String_De_Conexão");
                conn.Open();

                string sql = "SELECT * FROM Clientes WHERE Email@email AND Senha=@senha";

                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@email", txtCelularEmail.Text);
                cmd.Parameters.AddWithValue("@Senha", txtSenha.Text);

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    MessageBox.Show("Login Realizado com sucesso");

                    TelaLogin telaprincipal = new TelaLogin();
                    telaprincipal.Show();

                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Email ou senha inválidos!, tente novamente");
                }

                conn.Close();
            }
            catch (Exception erro)
            {
                MessageBox.Show("Erro: " + erro.Message);
            }
        }




        private void txtCelular_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNomeCompleto_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
