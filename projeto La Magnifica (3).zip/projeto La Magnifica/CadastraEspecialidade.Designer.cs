﻿namespace Projeto_La_Magnifica
{
    partial class CadastraEspecialidade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomeEspecialidade = new System.Windows.Forms.Label();
            this.lblValor = new System.Windows.Forms.Label();
            this.cmbNomeEspecialidade = new System.Windows.Forms.ComboBox();
            this.txtValor = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblNomeEspecialidade
            // 
            this.lblNomeEspecialidade.AutoSize = true;
            this.lblNomeEspecialidade.Location = new System.Drawing.Point(23, 101);
            this.lblNomeEspecialidade.Name = "lblNomeEspecialidade";
            this.lblNomeEspecialidade.Size = new System.Drawing.Size(121, 13);
            this.lblNomeEspecialidade.TabIndex = 0;
            this.lblNomeEspecialidade.Text = "Nome Da Especialidade";
            // 
            // lblValor
            // 
            this.lblValor.AutoSize = true;
            this.lblValor.Location = new System.Drawing.Point(32, 177);
            this.lblValor.Name = "lblValor";
            this.lblValor.Size = new System.Drawing.Size(31, 13);
            this.lblValor.TabIndex = 1;
            this.lblValor.Text = "Valor";
            // 
            // cmbNomeEspecialidade
            // 
            this.cmbNomeEspecialidade.FormattingEnabled = true;
            this.cmbNomeEspecialidade.Location = new System.Drawing.Point(177, 93);
            this.cmbNomeEspecialidade.Name = "cmbNomeEspecialidade";
            this.cmbNomeEspecialidade.Size = new System.Drawing.Size(121, 21);
            this.cmbNomeEspecialidade.TabIndex = 2;
            // 
            // txtValor
            // 
            this.txtValor.Location = new System.Drawing.Point(97, 177);
            this.txtValor.Name = "txtValor";
            this.txtValor.Size = new System.Drawing.Size(100, 20);
            this.txtValor.TabIndex = 3;
            // 
            // CadastraEspecialidade
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtValor);
            this.Controls.Add(this.cmbNomeEspecialidade);
            this.Controls.Add(this.lblValor);
            this.Controls.Add(this.lblNomeEspecialidade);
            this.Name = "CadastraEspecialidade";
            this.Text = "CadastraEspecialidade";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeEspecialidade;
        private System.Windows.Forms.Label lblValor;
        private System.Windows.Forms.ComboBox cmbNomeEspecialidade;
        private System.Windows.Forms.TextBox txtValor;
    }
}