﻿namespace Projeto_La_Magnifica
{
    partial class CadastraFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomeFuncionario = new System.Windows.Forms.Label();
            this.lblSobrenomeFuncionario = new System.Windows.Forms.Label();
            this.lblEspecialidade = new System.Windows.Forms.Label();
            this.txtnomeFuncionario = new System.Windows.Forms.TextBox();
            this.txtSobrenomeFuncionario = new System.Windows.Forms.TextBox();
            this.txtEspecialidade = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblNomeFuncionario
            // 
            this.lblNomeFuncionario.AutoSize = true;
            this.lblNomeFuncionario.Location = new System.Drawing.Point(23, 54);
            this.lblNomeFuncionario.Name = "lblNomeFuncionario";
            this.lblNomeFuncionario.Size = new System.Drawing.Size(93, 13);
            this.lblNomeFuncionario.TabIndex = 0;
            this.lblNomeFuncionario.Text = "Nome Funcionario";
            // 
            // lblSobrenomeFuncionario
            // 
            this.lblSobrenomeFuncionario.AutoSize = true;
            this.lblSobrenomeFuncionario.Location = new System.Drawing.Point(2, 122);
            this.lblSobrenomeFuncionario.Name = "lblSobrenomeFuncionario";
            this.lblSobrenomeFuncionario.Size = new System.Drawing.Size(132, 13);
            this.lblSobrenomeFuncionario.TabIndex = 1;
            this.lblSobrenomeFuncionario.Text = "sobrenome do Funcionario";
            // 
            // lblEspecialidade
            // 
            this.lblEspecialidade.AutoSize = true;
            this.lblEspecialidade.Location = new System.Drawing.Point(12, 209);
            this.lblEspecialidade.Name = "lblEspecialidade";
            this.lblEspecialidade.Size = new System.Drawing.Size(73, 13);
            this.lblEspecialidade.TabIndex = 2;
            this.lblEspecialidade.Text = "Especialidade";
            // 
            // txtnomeFuncionario
            // 
            this.txtnomeFuncionario.Location = new System.Drawing.Point(149, 54);
            this.txtnomeFuncionario.Name = "txtnomeFuncionario";
            this.txtnomeFuncionario.Size = new System.Drawing.Size(100, 20);
            this.txtnomeFuncionario.TabIndex = 3;
            // 
            // txtSobrenomeFuncionario
            // 
            this.txtSobrenomeFuncionario.Location = new System.Drawing.Point(149, 115);
            this.txtSobrenomeFuncionario.Name = "txtSobrenomeFuncionario";
            this.txtSobrenomeFuncionario.Size = new System.Drawing.Size(100, 20);
            this.txtSobrenomeFuncionario.TabIndex = 4;
            // 
            // txtEspecialidade
            // 
            this.txtEspecialidade.Location = new System.Drawing.Point(149, 202);
            this.txtEspecialidade.Name = "txtEspecialidade";
            this.txtEspecialidade.Size = new System.Drawing.Size(100, 20);
            this.txtEspecialidade.TabIndex = 5;
            // 
            // CadastraFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtEspecialidade);
            this.Controls.Add(this.txtSobrenomeFuncionario);
            this.Controls.Add(this.txtnomeFuncionario);
            this.Controls.Add(this.lblEspecialidade);
            this.Controls.Add(this.lblSobrenomeFuncionario);
            this.Controls.Add(this.lblNomeFuncionario);
            this.Name = "CadastraFuncionario";
            this.Text = "CadastraFuncionario";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeFuncionario;
        private System.Windows.Forms.Label lblSobrenomeFuncionario;
        private System.Windows.Forms.Label lblEspecialidade;
        private System.Windows.Forms.TextBox txtnomeFuncionario;
        private System.Windows.Forms.TextBox txtSobrenomeFuncionario;
        private System.Windows.Forms.TextBox txtEspecialidade;
    }
}