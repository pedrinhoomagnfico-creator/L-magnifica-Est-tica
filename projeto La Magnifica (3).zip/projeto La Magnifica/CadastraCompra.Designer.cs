﻿namespace Projeto_La_Magnifica
{
    partial class CadastraCompra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomeCompra = new System.Windows.Forms.Label();
            this.lblCodigo = new System.Windows.Forms.Label();
            this.lblPagamentos = new System.Windows.Forms.Label();
            this.lblVendedor = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.txtNomeCompra = new System.Windows.Forms.TextBox();
            this.txtCodCompra = new System.Windows.Forms.TextBox();
            this.txtPagamentos = new System.Windows.Forms.TextBox();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.txtVendedor = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblNomeCompra
            // 
            this.lblNomeCompra.AutoSize = true;
            this.lblNomeCompra.Location = new System.Drawing.Point(25, 64);
            this.lblNomeCompra.Name = "lblNomeCompra";
            this.lblNomeCompra.Size = new System.Drawing.Size(90, 13);
            this.lblNomeCompra.TabIndex = 0;
            this.lblNomeCompra.Text = "Nome Da compra";
            // 
            // lblCodigo
            // 
            this.lblCodigo.AutoSize = true;
            this.lblCodigo.Location = new System.Drawing.Point(25, 134);
            this.lblCodigo.Name = "lblCodigo";
            this.lblCodigo.Size = new System.Drawing.Size(94, 13);
            this.lblCodigo.TabIndex = 1;
            this.lblCodigo.Text = "código Da compra";
            // 
            // lblPagamentos
            // 
            this.lblPagamentos.AutoSize = true;
            this.lblPagamentos.Location = new System.Drawing.Point(25, 209);
            this.lblPagamentos.Name = "lblPagamentos";
            this.lblPagamentos.Size = new System.Drawing.Size(66, 13);
            this.lblPagamentos.TabIndex = 2;
            this.lblPagamentos.Text = "Pagamentos";
            // 
            // lblVendedor
            // 
            this.lblVendedor.AutoSize = true;
            this.lblVendedor.Location = new System.Drawing.Point(25, 279);
            this.lblVendedor.Name = "lblVendedor";
            this.lblVendedor.Size = new System.Drawing.Size(53, 13);
            this.lblVendedor.TabIndex = 3;
            this.lblVendedor.Text = "Vendedor";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(25, 370);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(31, 13);
            this.lblTotal.TabIndex = 4;
            this.lblTotal.Text = "Total";
            // 
            // txtNomeCompra
            // 
            this.txtNomeCompra.Location = new System.Drawing.Point(150, 57);
            this.txtNomeCompra.Name = "txtNomeCompra";
            this.txtNomeCompra.Size = new System.Drawing.Size(100, 20);
            this.txtNomeCompra.TabIndex = 5;
            // 
            // txtCodCompra
            // 
            this.txtCodCompra.Location = new System.Drawing.Point(150, 143);
            this.txtCodCompra.Name = "txtCodCompra";
            this.txtCodCompra.Size = new System.Drawing.Size(100, 20);
            this.txtCodCompra.TabIndex = 6;
            // 
            // txtPagamentos
            // 
            this.txtPagamentos.Location = new System.Drawing.Point(150, 220);
            this.txtPagamentos.Name = "txtPagamentos";
            this.txtPagamentos.Size = new System.Drawing.Size(100, 20);
            this.txtPagamentos.TabIndex = 7;
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(124, 363);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(100, 20);
            this.txtTotal.TabIndex = 8;
            // 
            // txtVendedor
            // 
            this.txtVendedor.Location = new System.Drawing.Point(150, 289);
            this.txtVendedor.Name = "txtVendedor";
            this.txtVendedor.Size = new System.Drawing.Size(100, 20);
            this.txtVendedor.TabIndex = 9;
            // 
            // CadastraCompra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtVendedor);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.txtPagamentos);
            this.Controls.Add(this.txtCodCompra);
            this.Controls.Add(this.txtNomeCompra);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblVendedor);
            this.Controls.Add(this.lblPagamentos);
            this.Controls.Add(this.lblCodigo);
            this.Controls.Add(this.lblNomeCompra);
            this.Name = "CadastraCompra";
            this.Text = "CadastraCompra";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeCompra;
        private System.Windows.Forms.Label lblCodigo;
        private System.Windows.Forms.Label lblPagamentos;
        private System.Windows.Forms.Label lblVendedor;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.TextBox txtNomeCompra;
        private System.Windows.Forms.TextBox txtCodCompra;
        private System.Windows.Forms.TextBox txtPagamentos;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.TextBox txtVendedor;
    }
}