﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_La_Magnifica
{
    internal class CarregaComboBox
    {

    }
}
