﻿namespace Projeto_La_Magnifica
{
    partial class Agendamento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.lblData = new System.Windows.Forms.Label();
            this.txtHora = new System.Windows.Forms.TextBox();
            this.dtpData = new System.Windows.Forms.DateTimePicker();
            this.lblhora = new System.Windows.Forms.Label();
            this.lblServiço = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.txtServiço = new System.Windows.Forms.TextBox();
            this.BtnAgendar = new System.Windows.Forms.Button();
            this.btnAtualizar = new System.Windows.Forms.Button();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblData.Location = new System.Drawing.Point(140, 22);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(33, 15);
            this.lblData.TabIndex = 1;
            this.lblData.Text = "Data";
            // 
            // txtHora
            // 
            this.txtHora.Location = new System.Drawing.Point(214, 76);
            this.txtHora.Name = "txtHora";
            this.txtHora.Size = new System.Drawing.Size(100, 20);
            this.txtHora.TabIndex = 2;
            // 
            // dtpData
            // 
            this.dtpData.Location = new System.Drawing.Point(196, 18);
            this.dtpData.Name = "dtpData";
            this.dtpData.Size = new System.Drawing.Size(235, 20);
            this.dtpData.TabIndex = 4;
            this.dtpData.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // lblhora
            // 
            this.lblhora.AutoSize = true;
            this.lblhora.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhora.Location = new System.Drawing.Point(140, 61);
            this.lblhora.Name = "lblhora";
            this.lblhora.Size = new System.Drawing.Size(34, 15);
            this.lblhora.TabIndex = 5;
            this.lblhora.Text = "Hora";
            // 
            // lblServiço
            // 
            this.lblServiço.AutoSize = true;
            this.lblServiço.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServiço.Location = new System.Drawing.Point(140, 108);
            this.lblServiço.Name = "lblServiço";
            this.lblServiço.Size = new System.Drawing.Size(47, 15);
            this.lblServiço.TabIndex = 6;
            this.lblServiço.Text = "Serviço";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.Location = new System.Drawing.Point(146, 157);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(41, 15);
            this.lblStatus.TabIndex = 7;
            this.lblStatus.Text = "Status";
            // 
            // txtServiço
            // 
            this.txtServiço.Location = new System.Drawing.Point(214, 122);
            this.txtServiço.Name = "txtServiço";
            this.txtServiço.Size = new System.Drawing.Size(100, 20);
            this.txtServiço.TabIndex = 8;
            // 
            // BtnAgendar
            // 
            this.BtnAgendar.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.BtnAgendar.Location = new System.Drawing.Point(132, 245);
            this.BtnAgendar.Name = "BtnAgendar";
            this.BtnAgendar.Size = new System.Drawing.Size(92, 40);
            this.BtnAgendar.TabIndex = 9;
            this.BtnAgendar.Text = "Agendar";
            this.BtnAgendar.UseVisualStyleBackColor = true;
            this.BtnAgendar.Click += new System.EventHandler(this.BtnAgendar_Click);
            // 
            // btnAtualizar
            // 
            this.btnAtualizar.ForeColor = System.Drawing.Color.DarkViolet;
            this.btnAtualizar.Location = new System.Drawing.Point(296, 239);
            this.btnAtualizar.Name = "btnAtualizar";
            this.btnAtualizar.Size = new System.Drawing.Size(75, 46);
            this.btnAtualizar.TabIndex = 10;
            this.btnAtualizar.Text = "Atualizar";
            this.btnAtualizar.UseVisualStyleBackColor = true;
            // 
            // btnExcluir
            // 
            this.btnExcluir.ForeColor = System.Drawing.Color.DarkMagenta;
            this.btnExcluir.Location = new System.Drawing.Point(422, 239);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(75, 46);
            this.btnExcluir.TabIndex = 11;
            this.btnExcluir.Text = "Excluir";
            this.btnExcluir.UseVisualStyleBackColor = true;
            // 
            // btnLimpar
            // 
            this.btnLimpar.ForeColor = System.Drawing.Color.DarkViolet;
            this.btnLimpar.Location = new System.Drawing.Point(567, 239);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnLimpar.Size = new System.Drawing.Size(75, 46);
            this.btnLimpar.TabIndex = 12;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            // 
            // txtStatus
            // 
            this.txtStatus.Location = new System.Drawing.Point(214, 157);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(100, 20);
            this.txtStatus.TabIndex = 13;
            // 
            // Agendamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnExcluir);
            this.Controls.Add(this.btnAtualizar);
            this.Controls.Add(this.BtnAgendar);
            this.Controls.Add(this.txtServiço);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblServiço);
            this.Controls.Add(this.lblhora);
            this.Controls.Add(this.dtpData);
            this.Controls.Add(this.txtHora);
            this.Controls.Add(this.lblData);
            this.Name = "Agendamento";
            this.Text = "Agendamento";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.TextBox txtHora;
        private System.Windows.Forms.DateTimePicker dtpData;
        private System.Windows.Forms.Label lblhora;
        private System.Windows.Forms.Label lblServiço;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.TextBox txtServiço;
        private System.Windows.Forms.Button BtnAgendar;
        private System.Windows.Forms.Button btnAtualizar;
        private System.Windows.Forms.Button btnExcluir;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.TextBox txtStatus;
    }
}