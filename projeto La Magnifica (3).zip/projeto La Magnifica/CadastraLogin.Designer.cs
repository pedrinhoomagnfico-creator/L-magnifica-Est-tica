﻿namespace Projeto_La_Magnifica
{
    partial class CadastraLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomeCompleto = new System.Windows.Forms.Label();
            this.lblEmailCelular = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblSenha = new System.Windows.Forms.Label();
            this.lblCelularEmail = new System.Windows.Forms.Label();
            this.lblDataNascimento = new System.Windows.Forms.Label();
            this.txtNomeCompleto = new System.Windows.Forms.TextBox();
            this.txtCelularEmail = new System.Windows.Forms.TextBox();
            this.txtSenha = new System.Windows.Forms.TextBox();
            this.txtDataNascimento = new System.Windows.Forms.TextBox();
            this.lblRepitaSenha = new System.Windows.Forms.Label();
            this.txtRepitaSenha = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.picLogonEmpresa = new System.Windows.Forms.PictureBox();
            this.btnCadastraLogin = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lblEnderecoCompleto = new System.Windows.Forms.Label();
            this.txtEndereçoCompleto = new System.Windows.Forms.TextBox();
            this.btnLoginTela = new System.Windows.Forms.Button();
            this.txtCelular = new System.Windows.Forms.TextBox();
            this.lblcelular = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picLogonEmpresa)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNomeCompleto
            // 
            this.lblNomeCompleto.AutoSize = true;
            this.lblNomeCompleto.Location = new System.Drawing.Point(521, 95);
            this.lblNomeCompleto.Name = "lblNomeCompleto";
            this.lblNomeCompleto.Size = new System.Drawing.Size(82, 13);
            this.lblNomeCompleto.TabIndex = 0;
            this.lblNomeCompleto.Text = "Nome Completo";
            // 
            // lblEmailCelular
            // 
            this.lblEmailCelular.AutoSize = true;
            this.lblEmailCelular.Location = new System.Drawing.Point(12, 134);
            this.lblEmailCelular.Name = "lblEmailCelular";
            this.lblEmailCelular.Size = new System.Drawing.Size(0, 13);
            this.lblEmailCelular.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 225);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 2;
            // 
            // lblSenha
            // 
            this.lblSenha.AutoSize = true;
            this.lblSenha.Location = new System.Drawing.Point(521, 225);
            this.lblSenha.Name = "lblSenha";
            this.lblSenha.Size = new System.Drawing.Size(38, 13);
            this.lblSenha.TabIndex = 3;
            this.lblSenha.Text = "Senha";
            // 
            // lblCelularEmail
            // 
            this.lblCelularEmail.AutoSize = true;
            this.lblCelularEmail.Location = new System.Drawing.Point(521, 134);
            this.lblCelularEmail.Name = "lblCelularEmail";
            this.lblCelularEmail.Size = new System.Drawing.Size(82, 13);
            this.lblCelularEmail.TabIndex = 4;
            this.lblCelularEmail.Text = "Email ou Celular";
            // 
            // lblDataNascimento
            // 
            this.lblDataNascimento.AutoSize = true;
            this.lblDataNascimento.Location = new System.Drawing.Point(521, 327);
            this.lblDataNascimento.Name = "lblDataNascimento";
            this.lblDataNascimento.Size = new System.Drawing.Size(104, 13);
            this.lblDataNascimento.TabIndex = 5;
            this.lblDataNascimento.Text = "Data de Nascimento";
            // 
            // txtNomeCompleto
            // 
            this.txtNomeCompleto.Location = new System.Drawing.Point(652, 95);
            this.txtNomeCompleto.Name = "txtNomeCompleto";
            this.txtNomeCompleto.Size = new System.Drawing.Size(100, 20);
            this.txtNomeCompleto.TabIndex = 6;
            this.txtNomeCompleto.TextChanged += new System.EventHandler(this.txtNomeCompleto_TextChanged);
            // 
            // txtCelularEmail
            // 
            this.txtCelularEmail.Location = new System.Drawing.Point(652, 134);
            this.txtCelularEmail.Name = "txtCelularEmail";
            this.txtCelularEmail.Size = new System.Drawing.Size(100, 20);
            this.txtCelularEmail.TabIndex = 7;
            // 
            // txtSenha
            // 
            this.txtSenha.Location = new System.Drawing.Point(652, 225);
            this.txtSenha.Name = "txtSenha";
            this.txtSenha.Size = new System.Drawing.Size(100, 20);
            this.txtSenha.TabIndex = 8;
            // 
            // txtDataNascimento
            // 
            this.txtDataNascimento.Location = new System.Drawing.Point(652, 324);
            this.txtDataNascimento.Name = "txtDataNascimento";
            this.txtDataNascimento.Size = new System.Drawing.Size(100, 20);
            this.txtDataNascimento.TabIndex = 9;
            // 
            // lblRepitaSenha
            // 
            this.lblRepitaSenha.AutoSize = true;
            this.lblRepitaSenha.Location = new System.Drawing.Point(521, 278);
            this.lblRepitaSenha.Name = "lblRepitaSenha";
            this.lblRepitaSenha.Size = new System.Drawing.Size(81, 13);
            this.lblRepitaSenha.TabIndex = 10;
            this.lblRepitaSenha.Text = "Repita a Senha";
            // 
            // txtRepitaSenha
            // 
            this.txtRepitaSenha.Location = new System.Drawing.Point(652, 271);
            this.txtRepitaSenha.Name = "txtRepitaSenha";
            this.txtRepitaSenha.Size = new System.Drawing.Size(100, 20);
            this.txtRepitaSenha.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label1.Location = new System.Drawing.Point(542, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 31);
            this.label1.TabIndex = 12;
            this.label1.Text = "Registre-Se";
            // 
            // picLogonEmpresa
            // 
            this.picLogonEmpresa.Location = new System.Drawing.Point(12, 40);
            this.picLogonEmpresa.Name = "picLogonEmpresa";
            this.picLogonEmpresa.Size = new System.Drawing.Size(261, 326);
            this.picLogonEmpresa.TabIndex = 13;
            this.picLogonEmpresa.TabStop = false;
            // 
            // btnCadastraLogin
            // 
            this.btnCadastraLogin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnCadastraLogin.Location = new System.Drawing.Point(592, 396);
            this.btnCadastraLogin.Name = "btnCadastraLogin";
            this.btnCadastraLogin.Size = new System.Drawing.Size(123, 42);
            this.btnCadastraLogin.TabIndex = 14;
            this.btnCadastraLogin.Text = "Cadastra-Se";
            this.btnCadastraLogin.UseVisualStyleBackColor = true;
            this.btnCadastraLogin.Click += new System.EventHandler(this.btnCadastraLogin_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label2.Location = new System.Drawing.Point(565, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "Já Cadastrado?  Login";
            // 
            // lblEnderecoCompleto
            // 
            this.lblEnderecoCompleto.AutoSize = true;
            this.lblEnderecoCompleto.Location = new System.Drawing.Point(521, 180);
            this.lblEnderecoCompleto.Name = "lblEnderecoCompleto";
            this.lblEnderecoCompleto.Size = new System.Drawing.Size(100, 13);
            this.lblEnderecoCompleto.TabIndex = 16;
            this.lblEnderecoCompleto.Text = "Endereço Completo";
            // 
            // txtEndereçoCompleto
            // 
            this.txtEndereçoCompleto.Location = new System.Drawing.Point(652, 177);
            this.txtEndereçoCompleto.Name = "txtEndereçoCompleto";
            this.txtEndereçoCompleto.Size = new System.Drawing.Size(100, 20);
            this.txtEndereçoCompleto.TabIndex = 17;
            // 
            // btnLoginTela
            // 
            this.btnLoginTela.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnLoginTela.Location = new System.Drawing.Point(374, 376);
            this.btnLoginTela.Name = "btnLoginTela";
            this.btnLoginTela.Size = new System.Drawing.Size(111, 62);
            this.btnLoginTela.TabIndex = 18;
            this.btnLoginTela.Text = "Já cadastrado? Login";
            this.btnLoginTela.UseVisualStyleBackColor = true;
            this.btnLoginTela.Click += new System.EventHandler(this.btnLoginTela_Click);
            // 
            // txtCelular
            // 
            this.txtCelular.Location = new System.Drawing.Point(652, 366);
            this.txtCelular.Name = "txtCelular";
            this.txtCelular.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtCelular.Size = new System.Drawing.Size(100, 20);
            this.txtCelular.TabIndex = 19;
            this.txtCelular.TextChanged += new System.EventHandler(this.txtCelular_TextChanged);
            // 
            // lblcelular
            // 
            this.lblcelular.AutoSize = true;
            this.lblcelular.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcelular.Location = new System.Drawing.Point(545, 370);
            this.lblcelular.Name = "lblcelular";
            this.lblcelular.Size = new System.Drawing.Size(49, 16);
            this.lblcelular.TabIndex = 20;
            this.lblcelular.Text = "Celular";
            // 
            // CadastraLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblcelular);
            this.Controls.Add(this.txtCelular);
            this.Controls.Add(this.btnLoginTela);
            this.Controls.Add(this.txtEndereçoCompleto);
            this.Controls.Add(this.lblEnderecoCompleto);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnCadastraLogin);
            this.Controls.Add(this.picLogonEmpresa);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtRepitaSenha);
            this.Controls.Add(this.lblRepitaSenha);
            this.Controls.Add(this.txtDataNascimento);
            this.Controls.Add(this.txtSenha);
            this.Controls.Add(this.txtCelularEmail);
            this.Controls.Add(this.txtNomeCompleto);
            this.Controls.Add(this.lblDataNascimento);
            this.Controls.Add(this.lblCelularEmail);
            this.Controls.Add(this.lblSenha);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblEmailCelular);
            this.Controls.Add(this.lblNomeCompleto);
            this.Name = "CadastraLogin";
            this.Text = "CadastraLogin";
            ((System.ComponentModel.ISupportInitialize)(this.picLogonEmpresa)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeCompleto;
        private System.Windows.Forms.Label lblEmailCelular;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblSenha;
        private System.Windows.Forms.Label lblCelularEmail;
        private System.Windows.Forms.Label lblDataNascimento;
        private System.Windows.Forms.TextBox txtNomeCompleto;
        private System.Windows.Forms.TextBox txtCelularEmail;
        private System.Windows.Forms.TextBox txtSenha;
        private System.Windows.Forms.TextBox txtDataNascimento;
        private System.Windows.Forms.Label lblRepitaSenha;
        private System.Windows.Forms.TextBox txtRepitaSenha;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox picLogonEmpresa;
        private System.Windows.Forms.Button btnCadastraLogin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblEnderecoCompleto;
        private System.Windows.Forms.TextBox txtEndereçoCompleto;
        private System.Windows.Forms.Button btnLoginTela;
        private System.Windows.Forms.TextBox txtCelular;
        private System.Windows.Forms.Label lblcelular;
    }
}